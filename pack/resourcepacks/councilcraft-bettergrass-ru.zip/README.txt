CouncilCraft LambdaBetterGrass data for Regions Unexplored.
Grass/path data loads textures from Regions Unexplored, Minecraft and LambdaBetterGrass.
Snowy fences (22 RU fences + pale_oak_fence, states + data, tools/mklbgfences.py): models reference each
wood's own planks texture from the installed mod (no Regions Unexplored or Vanilla Backport pixels are
shipped here) and lay the snow overlay of LambdaBetterGrass's snowy fence textures by LambdAurora on top,
from its MIT-licensed legacy/mit branch (https://github.com/LambdAurora/LambdaBetterGrass/tree/legacy/mit,
commit 05428aa). Shipped textures: snowy_fence_overlay_post.png and snowy_fence_overlay_side.png only
(the overlay pixels, extracted from LambdaBetterGrass; modified: separated from the vanilla planks).
Model geometry follows LambdaBetterGrass's MIT snowy fence templates. MIT notice: LICENSE-LambdaBetterGrass.txt.
