CouncilCraft LambdaBetterGrass data for Regions Unexplored.
Grass/path data loads textures from Regions Unexplored, Minecraft and LambdaBetterGrass.
Snowy fences (22 RU fences + pale_oak_fence, states + data, tools/mklbgfences.py): each wood's planks texture with
vanilla snow pixels on a fixed cap-and-drip mask. Models reference LambdaBetterGrass (LambdAurora)
snowy fence templates by name; no LambdaBetterGrass files are included.
