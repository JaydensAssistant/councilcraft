CouncilCraft LambdaBetterGrass data for Regions Unexplored.
Grass/path data loads textures from Regions Unexplored, Minecraft and LambdaBetterGrass.
Snowy fences (22 RU fences + pale_oak_fence, states + data, tools/mklbgfences.py): each wood's planks texture
under the snow overlay of LambdaBetterGrass's snowy fence textures by LambdAurora, from its MIT-licensed
legacy/mit branch (https://github.com/LambdAurora/LambdaBetterGrass/tree/legacy/mit, commit 05428aa).
Modified: overlay laid on other woods' planks. MIT notice: LICENSE-LambdaBetterGrass.txt.
Models reference the LambdaBetterGrass snowy fence templates by name.
