CouncilCraft connected prismaglass (PPM53), rendered by Continuity.
Tiles are vanilla white_stained_glass (the texture prismaglass renders, tinted) with joined edges opened procedurally; same tile layout as Continuity's default glass.
