Regions Unexplored: Expansion 1.0.1+1.20.1 by DropoutGuy (MIT), https://modrinth.com/mod/regions-unexplored-expansion
Repackaged as a data-only datapack for Fabric (data/ + pack.mcmeta; no code). Changes: all ru_expansion fallen_* tree features removed from the biome JSONs (S231; Vanilla Backport Spring to Life already adds fallen trees).
Source jar sha512: 2287ec90ebdfd6288396ab5f61099f35fde08788959876100ccd25cd671bd6e96cb5a5031336f181366fa375d94c58bf428ab09c93a31c18869233e8c7d682c9
